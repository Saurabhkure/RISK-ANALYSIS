<?php
require('db.php');
$user_id = $_SESSION["id"];


$query    = "SELECT * FROM `users` WHERE id=$user_id";
$result = mysqli_query($con, $query) or die(mysql_error());
$row = mysqli_fetch_assoc($result);

$username = $row['username'];




/*Constants */
$Project_name = "SHARKS";
?>