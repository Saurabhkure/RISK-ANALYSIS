CREATE TABLE IF NOT EXISTS `users` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `username` varchar(50) NOT NULL,
 `email` varchar(50) NOT NULL,
 `password` varchar(50) NOT NULL,
 `create_datetime` datetime NOT NULL,
 PRIMARY KEY (`id`)
);


CREATE TABLE transactions (
    CardNumber varchar(255),
    CustomerName varchar(255),
    Amount varchar(255),
    City varchar(255),
    IP varchar(255),
    PostalCode varchar(255)
);

INSERT INTO transactions
VALUES ("9818353750","SAURABH KURE","3500","LATUR","10.0.1.140","413512");